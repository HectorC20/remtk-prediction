# Arquitectura

## Visión de conjunto

`remtk-prediction` es un **servicio unificado en un solo proceso Node**. Sustituye
al antiguo server Go y a los tres servicios separados del monolith (embeddings,
Qdrant y predicción) manteniendo **contratos HTTP 1:1**. Puede ejecutarse de dos
formas:

- **Como librería in-process** (sin abrir puertos): `import { createSystem } from "remtk-prediction"`.
- **Como servidor HTTP** de 3 puertos: `node dist/src/server.js` (entry `src/server.ts`).

```
                  ┌───────────────────────────────────────────────┐
   NestJS/otros    │                Proceso Node                   │
   (consumidores)  │                                               │
       │  HTTP     │   ┌─────────────────────────────────────┐     │
       ├──────────►│   │  createSystem(cfg)  (src/main.ts)    │     │
       │           │   │                                     │     │
       │           │   │  EmbeddingEngineService  (e5-small)  │    │  ┌─────────────┐
       │           │   │  QdrantService  ─────────────────────┼───►│  Qdrant HTTP │
       │           │   │  TurnClassifier                      │    │  (6333)      │
       │           │   │  KeywordService                      │    └─────────────┘
       │           │   │  ToolGraphCacheService (grafo)       │
       │           │   │  SessionStateCacheService (z_t)      │
       │           │   │  RerankService (graphFilter/topo)    │
       │           │   │  ConfirmationCache · Debugger        │
       │           │   │  PredictionOrchestrator              │
       │           │   └─────────────────────────────────────┘     │
       │           │                                               │
       │           │  Express 6776 (predicción)  PredictAppModule  │
       │           │  Express 6777 (modelos)     EmbeddingAppModule│
       │           │  Express 6775 (Qdrant API)  QdrantAppModule   │
       └───────────┼───────────────────────────────────────────────┘
```

## Puntos de entrada

| Archivo | Rol |
|---|---|
| `src/index.ts` | API pública de librería. Exporta `createSystem`, `loadConfig`, servicios núcleo y tipos. |
| `src/main.ts` | `createSystem(cfg)`: construye el grafo de servicios. Define la interfaz `System`. |
| `src/server.ts` | Entry del servidor: carga config, crea el sistema y arranca los 3 listeners HTTP. |
| `src/app.module.ts` | `startPredictServer`/`startEmbedServer`/`startQdrantServer`: apps Nest autocontenidas (6776/6777/6775) con parser `express.json({ limit: "4mb" })`. |
| `src/config.ts` | `loadConfig(env?)`: configuración tipada desde variables de entorno. |
| `src/logger.ts` | Logger compacto con timestamp ISO (`log`/`warn`) que escribe a consola y a un **archivo diario** (`logs/prediction-YYYY-MM-DD.log` o `LOGS_DIR`). |
| `src/shared/interfaces/` | Tipos de dominio y contrato (`ToolDefinition`, `PredictionInput`, `Trace`, `GraphPredictionResult`, etc.). |

## Grafo de dependencias (`src/main.ts`)

```
cfg ──► EmbeddingEngineService ───┐
 │                             ├─► TurnClassifier
 │     QdrantService ──────────┤    RerankService
 │      (asegura colecciones)  │    ConfirmationCache
 │                             ├─► PredictionOrchestrator
 │                             │    KeywordService
 │                             ├─► ToolGraphCacheService
 │                             ├─► SessionStateCacheService
 │                             └─► Debugger
```

`createSystem` construye en orden: engine (con `warmup()` en background) →
qdrant (`ensureCollections()` si está habilitado) → classifier, confirmCache,
keywords, **graphCache**, **sessionState**, debugger y rerank → orquestador
(vía `shared/factory/orchestrator.factory.ts`, `createOrchestrator`).

`PredictionOrchestrator` recibe todos los servicios y expone:

- `predict(input)` — pipeline de tools; devuelve `GraphPredictionResult`
  (resultado + bloque `graph` con `nodes`, `edges` y `executionOrder`).
- `predictMemory(input)` — pipeline de memorias contextuales.
- `registerTools(tenant, tools)` — registro/indexado; además de Qdrant y
  keywords, **reconstruye el grafo del tenant** (`graphCache.buildTenantGraph`).
- `countTools(tenant)`.

## Mapas por directorio

```
src/
├── embedding/
│   ├── embedding.controller.ts  API 6777 (POST /embed, GET /models, /health)
│   ├── embedding.module.ts      App Nest de modelos (EmbeddingAppModule)
│   └── embedding.service.ts     Motor ONNX (EmbeddingEngineService): e5-small
│                                (default) / e5-large (a demanda) + fallback hash
│                                + cola prioritaria
├── predict/
│   ├── predict.controller.ts    API 6776 (HTTP del pipeline)
│   ├── predict.module.ts        App Nest de predicción (PredictAppModule)
│   ├── orchestrator.ts          Orquestador (predict / memoryPredict / registerTools)
│   ├── turn-classifier.ts       Clasificador de turno (TurnType: new_query /
│                                confirmation_empty / confirmation_nuance)
│   ├── keywords.ts              Utilidades de keywords (extractQueryKeywords,
│                                toolKeywords, normalizeToken)
│   ├── services/
│   │   ├── keyword.service.ts       Capas 1–2: keywords + match cross-idioma (reduce)
│   │   ├── graph-cache.service.ts   Grafo por tenant (nodos passage: + aristas +
│   │   │                            matriz de adyacencia N×N)
│   │   ├── session-state-cache.service.ts  Estado z_t por sesión (blend 70/30)
│   │   ├── rerank.service.ts        Capa 3: fusión BM25 + umbral adaptativo;
│   │   │                            graphFilter (propagación, mutexes, topo-sort)
│   │   └── confirm-cache.service.ts Caché de planes por sesión (early-exit)
│   └── helper/
│       └── debugger.helper.ts       Trazas en anillo + estadísticas (GET /debug)
├── qdrant/
│   ├── qdrant.controller.ts    API 6775 (recall, keywording, indexado)
│   ├── qdrant.module.ts        App Nest de Qdrant (QdrantAppModule)
│   ├── qdrant-service.ts       Orquestación Qdrant (sinónimos, RAKE, blend, catálogo)
│   └── qdrant-client.ts        Cliente HTTP mínimo hacia Qdrant (BM25 sparse, djb2, uuidv5)
├── shared/
│   ├── constants/              Puertos, tamaños de modelo y colecciones fijas
│   ├── dictionary/             Stopwords + tipos de turno (turn.dictionary.ts)
│   ├── factory/                Fábrica del orquestador (createOrchestrator)
│   └── interfaces/             Tipos de contrato y dominio (EmbedResult,
│                               ToolDefinition, GraphEdge, TenantToolGraph…)
└── config.ts · index.ts · logger.ts · main.ts · server.ts
```

## Servidores HTTP (ver [api-http.md](api-http.md))

Cada puerto es una **app Nest autocontenida** arrancada por `src/app.module.ts`
con el parser JSON `express.json({ limit: "4mb" })` (constante `LIMIT` en
`shared/constants/predict/data.predict.ts`):

| Puerto | App (arranque) | Roles |
|---|---|---|
| `6776` | `PredictAppModule` (`startPredictServer`) | Orquesta predicción y registro de tools; expone `/health`, `/debug`. |
| `6777` | `EmbeddingAppModule` (`startEmbedServer`) | Expone embeddings del modelo por defecto e5-small; `/models`, `/health`. |
| `6775` | `QdrantAppModule` (`startQdrantServer`) | Capa HTTP sobre el motor Qdrant; `/status`, `/health`. |

`server.ts` arranca los tres listeners en paralelo y registra apagado limpio con
`SIGINT`/`SIGTERM`.

## Arranque del proceso

```ts
const cfg = loadConfig();                       // env vars → defaults listos
const system = await createSystem(cfg);         // warmup ONNX + ensure colecciones
startPredictServer(...); startEmbedServer(...); startQdrantServer(...);
```

Durante `createSystem`:

1. `engine.warmup()` lanza en background la carga de la sesión ONNX de `small`
   (no bloquea). El clasificador carga sus arquetipos de forma perezosa en el
   primer `classify`.
2. Si `qdrantEnabled`, `qdrant.ensureCollections()` crea las 4 colecciones si no
   existen.

El grafo de cada tenant **no** se construye en el boot: se arma en `POST /tools`
(`registerTools`), cuando llega el catálogo.

## Degradación (principio de diseño)

Ninguna dependencia externa es crítica:

| Fallo | Comportamiento |
|---|---|
| ONNX no disponible / modelo incompleto | Embeddings por **hash determinístico** (djb2), `model = "hash"`. |
| Qdrant caído o deshabilitado | Recall BM25 vacío → la puntuación queda solo semántica (grafo o keywords). |
| Grafo del tenant ausente (tenant no registrado vía `POST /tools`) | Reduce **plano** por keywords cross-idioma sobre el catálogo completo. |
| Keyword reduce falla | Se usa el catálogo completo como candidatas. |
| Estado de sesión (`z_t`) falla | Se salta la ruta de grafo y se degrada a la reducción plana. |

Esto replica el comportamiento "soft-degrade" del sistema original: **el servicio
nunca falla por ausencia de modelos, de Qdrant o del grafo**.
