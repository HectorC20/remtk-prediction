/**
 * QdrantService: arquitectura Qdrant migrada de src (QdrantMemoryService +
 * ToolRetrievalService + KeywordingService) y del RecallService Go.
 * Orquesta: expansión por sinónimos → keywords (RAKE) → BM25 en paralelo
 * (mcp_tools + tool_keywords) → blend 60/40 → cruce con el catálogo del tenant.
 */
import { MemoryCandidate } from "..";
import type { AppConfig } from "../config";
import { log, warn } from "../logger";
import type { ScoredTool, ToolDefinition, ToolCatalog } from "../shared/interfaces/index";
import { QdrantClient, type SearchResult, uuidv5 } from "./qdrant-client";
import { toolIdentityTokens } from "../predict/keywords";
import { MAX_KEYWORDS, MAX_SEARCH_LIMIT, MAX_SYNONYM_EXPANSIONS } from "../shared/constants/qdrant/general.constant";

export type { ToolCatalog };

export class QdrantService {
  readonly client: QdrantClient;
  private readonly catalogs = new Map<string, Map<string, ToolDefinition>>();
  /**
   * Caché de sinónimos particionada por scopeKey (tenant::agentId). Nunca se
   * comparte entre canales: un sinónimo cacheado para el canal A no puede
   * servirse al canal B (§9.2 del plan de entrenamiento).
   */
  private readonly synonymCache = new Map<string, Map<string, string[]>>();

  constructor(private readonly config: AppConfig) {
    this.client = new QdrantClient(config);
  }

  /** Registra/actualiza el catálogo del scope (fuente de definiciones completas). */
  setCatalog(scopeKey: string, tools: ToolDefinition[]): void {
    const map = new Map<string, ToolDefinition>();
    for (const t of tools) map.set(t.name.trim(), t);
    this.catalogs.set(scopeKey, map);
  }

  catalog(scopeKey: string): ToolCatalog {
    const map = this.catalogs.get(scopeKey) ?? new Map<string, ToolDefinition>();
    return {
      get: (name: string) => map.get(name.trim()),
      all: () => [...map.values()],
    };
  }

  countTools(scopeKey: string): number {
    return this.catalogs.get(scopeKey)?.size ?? 0;
  }

  /** Crea las colecciones si no existen (no destructivo). */
  async ensureCollections(): Promise<void> {
    if (!this.client.enabled) return;
    for (const coll of [
      this.config.toolsCollection,
      this.config.keywordsCollection,
      this.config.synonymsCollection,
      this.config.memoriesCollection,
    ]) {
      try {
        await this.client.ensureSparseCollection(coll);
      } catch (err) {
        warn(`[qdrant] ensure ${coll} falló: ${String((err as Error)?.message ?? err)}`);
      }
    }
  }

  /**
   * Indexa las herramientas del scope en Qdrant (colecciones mcp_tools y
   * tool_keywords) con el mismo payload que ToolRetrievalService.syncTools.
   * El payload guarda el scopeKey como 'tenant': es la etiqueta con la que
   * `retrieveTools` filtra, no un dato informativo.
   */
  async indexTools(scopeKey: string, tools: ToolDefinition[]): Promise<void> {
    this.setCatalog(scopeKey, tools);
    if (!this.client.enabled) return;

    // IDs determinísticos POR ÁMBITO (uuidv5 DNS). El scopeKey entra en la clave
    // porque el recall filtra por `tenant`: si dos canales registran la misma
    // herramienta sobre un id compartido, el último writer se queda con el
    // payload y el otro canal pierde esa herramienta del recall.
    const toolPoints = tools.map((t) => ({
      id: uuidv5(`mcp-tool:${scopeKey}:${t.group || "general"}:${t.name}`),
      payload: {
        tenant: scopeKey,
        toolName: t.name,
        group: t.group,
        category: t.category,
        description: t.description,
        tags: t.tags ?? [],
        intentSummary: t.intentSummary,
        toolDocument: buildToolDocument(t),
      },
      vector: { bm25_text: this.client.textToSparseVector(buildToolDocument(t)) },
    }));

    // Una keyword-point por tool (mismo esquema tool-kw del monolith).
    const kwPoints: {
      id: string;
      payload: Record<string, unknown>;
      vector: Record<string, { indices: number[]; values: number[] }>;
    }[] = [];
    for (const t of tools) {
      const keywords = extractToolKeywords(t);
      if (keywords.length === 0) continue;
      kwPoints.push({
        id: uuidv5(`tool-kw:${scopeKey}:${t.group || "general"}:${t.name}`),
        payload: { tenant: scopeKey, toolName: t.name, keywords },
        vector: {
          bm25_text: this.client.textToSparseVector(keywords.join(" ")),
        },
      });
    }

    try {
      if (scopeKey !== "") {
        const ownScope = { must: [{ key: "tenant", match: { value: scopeKey } }] };
        await this.client.deletePointsByFilter(this.config.toolsCollection, ownScope);
        await this.client.deletePointsByFilter(this.config.keywordsCollection, ownScope);
      }
    } catch (err) {
      warn(`[qdrant] limpieza scope=${scopeKey} falló: ${String((err as Error)?.message ?? err)}`);
    }

    try {
      await this.client.upsertPoints(this.config.toolsCollection, toolPoints);
      if (kwPoints.length > 0) {
        await this.client.upsertPoints(this.config.keywordsCollection, kwPoints);
      }
      log(`[qdrant] indexados ${toolPoints.length} tools + ${kwPoints.length} keywords (scope=${scopeKey})`);
    } catch (err) {
      warn(`[qdrant] indexado falló: ${String((err as Error)?.message ?? err)}`);
    }
  }

  /**
   * Capa 1 del pipeline: recall BM25. Replica RecallService.RetrieveTools del Go.
   * Devuelve candidatas con score crudo de Qdrant (0-∞); vacío/error → el
   * orquestador degrada al catálogo completo.
   */
  async retrieveTools(scopeKey: string, prompt: string, limit: number): Promise<ScoredTool[]> {
    const raw = prompt.trim();
    const catalog = this.catalog(scopeKey);
    if (raw === "" || catalog.all().length === 0 || !this.client.enabled) return [];

    // 1. Expansión por sinónimos (cold start → query intacta), aislada por canal.
    const expanded = await this.expandSynonyms(raw, new Set(), scopeKey);

    // 2. Keywords RAKE.
    const keywords = extractKeywordsRake(raw, MAX_KEYWORDS);

    log(`[recall] query=${JSON.stringify(raw)} expanded=${JSON.stringify(expanded)} keywords=${JSON.stringify(keywords)}`);

    // 3. BM25 en paralelo (mcp_tools + tool_keywords), filtrados por el ámbito
    //    del canal. Sin el filtro, los hits de otros scopes desplazan a los
    //    propios en el top-k y el cruce posterior con el catálogo los descarta
    //    todos: `candidates=0` → el rerank pierde la señal léxica y decide por
    //    empate, que es lo que hacía impredecible la predicción entre corridas.
    const toolsFilter = scopeFilter(scopeKey);
    const promptMatches = await this.search(
      this.config.toolsCollection,
      expanded,
      Math.min(Math.max(limit * 3, 10), MAX_SEARCH_LIMIT),
      toolsFilter,
      ["toolName"],
    );
    const keywordMatches =
      keywords.length > 0
        ? await this.search(
            this.config.keywordsCollection,
            keywords.join(" "),
            Math.min(Math.max(limit * 2, 10), MAX_SEARCH_LIMIT),
            toolsFilter,
            ["toolName"],
          )
        : [];

    // Score de keywords por toolName.
    const keywordScore = new Map<string, number>();
    for (const m of keywordMatches) {
      const name = payloadString(m, "toolName");
      if (!name) continue;
      const cur = keywordScore.get(name);
      if (cur === undefined || m.score > cur) keywordScore.set(name, m.score);
    }
    const hasKeywords = keywordMatches.length > 0;

    log(`[recall] prompt_matches=${promptMatches.length} keyword_matches=${keywordMatches.length}`);

    // 4. Merge + blend 60/40 y cruce con el catálogo.
    const merged = new Map<string, { tool: ToolDefinition; blended: number }>();
    for (const m of promptMatches) {
      const name = payloadString(m, "toolName");
      if (!name) continue;
      const tool = catalog.get(name);
      if (!tool) continue;
      const blended = hasKeywords ? m.score * 0.6 + (keywordScore.get(name) ?? 0) * 0.4 : m.score;
      merged.set(name, { tool, blended });
    }

    const entries = [...merged.values()].sort((a, b) => b.blended - a.blended);
    const out = entries.slice(0, limit).map((e) => ({ name: e.tool.name, score: e.blended }));
    log(`[recall] candidates=${out.length}`);
    return out;
  }

  /**
   * Recall de memorias contextuales (BM25 filtrado por userId y, opcionalmente,
   * por agentId). Replica MemoryRecallService.
   *
   * Regla del filtro según agentId (normalizado, trim):
   *  - ausente/''  ⇒ legacy: must [{key:"userId", match}] (solo userId).
   *  - 'general'   ⇒ userId + should [{agentId=general}, {agentId is_empty}]:
   *                  las memorias legacy sin campo agentId también matchean.
   *  - concreto    ⇒ userId + agentId = valor exacto.
   */
  async searchMemories(
    userId: string,
    text: string,
    limit: number,
    agentId?: string,
  ): Promise<MemoryCandidate[]> {
    const raw = text.trim();
    if (raw === "" || userId === "" || !this.client.enabled) return [];
    const a = typeof agentId === "string" ? agentId.trim() : "";
    const filter =
      a === ""
        ? { must: [{ key: "userId", match: { value: userId } }] }
        : a === "general"
          ? {
              must: [
                { key: "userId", match: { value: userId } },
                {
                  should: [
                    { key: "agentId", match: { value: "general" } },
                    { is_empty: { key: "agentId" } },
                  ],
                },
              ],
            }
          : {
              must: [
                { key: "userId", match: { value: userId } },
                { key: "agentId", match: { value: a } },
              ],
            };
    const results = await this.search(
      this.config.memoriesCollection,
      raw,
      Math.min(Math.max(limit * 2, 10), MAX_SEARCH_LIMIT),
      filter,
      ["memoryId", "content", "chatId", "metadata", "createdAt"],
    );
    const out: MemoryCandidate[] = [];
    for (const r of results) {
      const id = payloadString(r, "memoryId") || r.id;
      const content = payloadString(r, "content");
      if (!id || !content.trim()) continue;
      out.push({
        memory: {
          id,
          content,
          chatId: payloadString(r, "chatId"),
          metadata: payloadObject(r, "metadata"),
          createdAt: payloadString(r, "createdAt"),
          score: 0,
        },
        retrievalScore: r.score,
      });
    }
    return out;
  }

  /**
   * Expansión de sinónimos (colección query_synonyms). Replica SynonymExpander.
   *
   * `scopeKey` (tenant::agentId) es obligatorio para el aislamiento: la caché y
   * la búsqueda en Qdrant quedan particionadas por canal. Si se omite, se usa
   * la partición pública (`""`), que solo ve puntos sin `tenant` asignado.
   */
  async expandSynonyms(
    query: string,
    toolNames: Set<string> = new Set(),
    scopeKey = "",
  ): Promise<string> {
    const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
    if (tokens.length === 0) return query;
    const seen = new Set(tokens);
    const expansions: string[] = [];
    // Lookups en paralelo para no amplificar latencias de Qdrant.
    const perToken = await Promise.all(
      tokens.map(async (token) => {
        const clean = cleanToken(token);
        if (clean.length < 2) return [];
        return this.lookupSynonyms(clean, scopeKey);
      }),
    );
    for (const syns of perToken) {
      for (const syn of syns) {
        if (seen.size >= MAX_SYNONYM_EXPANSIONS) break;
        // Filtro de contaminación: un sinónimo no debe ser un nombre de tool
        // del catálogo ni una frase larga inyectada desde una descripción.
        const synTokens = syn.toLowerCase().split(/\s+/).filter(Boolean);
        if (synTokens.length > 5 || toolNames.has(syn.toLowerCase())) continue;
        if (!seen.has(syn)) {
          seen.add(syn);
          expansions.push(syn);
        }
      }
    }
    if (expansions.length === 0) return query;
    return `${query} ${expansions.join(" ")}`;
  }

  private async lookupSynonyms(token: string, scopeKey: string): Promise<string[]> {
    if (!this.client.enabled) return [];
    let perScope = this.synonymCache.get(scopeKey);
    if (!perScope) {
      perScope = new Map<string, string[]>();
      this.synonymCache.set(scopeKey, perScope);
    }
    const cached = perScope.get(token);
    if (cached) return cached;
    try {
      const results = await this.search(
        this.config.synonymsCollection,
        token,
        3,
        scopeFilter(scopeKey),
        ["synonyms"],
      );
      const seen = new Set<string>();
      const out: string[] = [];
      for (const r of results) {
        const syns = r.payload["synonyms"];
        if (Array.isArray(syns)) {
          for (const syn of syns) {
            if (typeof syn === "string" && syn !== "" && !seen.has(syn)) {
              seen.add(syn);
              out.push(syn);
            }
          }
        }
      }
      perScope.set(token, out);
      return out;
    } catch {
      return [];
    }
  }

  private async search(
    collection: string,
    query: string,
    limit: number,
    filter?: unknown,
    include?: string[],
  ): Promise<SearchResult[]> {
    try {
      return await this.client.searchBm25(collection, query, limit, filter, include);
    } catch (err) {
      warn(`[qdrant] search ${collection} falló: ${String((err as Error)?.message ?? err)}`);
      return [];
    }
  }

  async status(): Promise<{ enabled: boolean; qdrant: { ok: boolean; collections: string[] } }> {
    const q = await this.client.getStatus();
    return { enabled: this.client.enabled, qdrant: q };
  }
}

function payloadString(r: SearchResult, key: string): string {
  const v = r.payload?.[key];
  return typeof v === "string" ? v : "";
}

/**
 * Filtro de aislamiento de las colecciones particionadas por ámbito
 * (`query_synonyms`, `mcp_tools`, `tool_keywords`).
 *
 * Acepta los puntos etiquetados con el `tenant` (scopeKey) del canal y,
 * además, los puntos legacy sin `tenant` (poblados por fuera de este servicio),
 * para no romper el comportamiento actual. Un punto etiquetado con OTRO canal
 * queda excluido: ahí está la garantía de no contaminación cruzada (§9.2).
 */
function scopeFilter(scopeKey: string): unknown {
  const should: Record<string, unknown>[] = [{ is_empty: { key: "tenant" } }];
  if (scopeKey !== "") should.push({ key: "tenant", match: { value: scopeKey } });
  return { should };
}

function payloadObject(r: SearchResult, key: string): Record<string, unknown> | undefined {
  const v = r.payload?.[key];
  return v && typeof v === "object" ? (v as Record<string, unknown>) : undefined;
}

function buildToolDocument(t: ToolDefinition): string {
  return [
    t.name,
    t.group,
    t.category,
    t.description,
    (t.tags ?? []).join(" "),
    t.intentSummary,
    JSON.stringify(t.inputSchema ?? {}),
  ]
    .filter(Boolean)
    .join(" ");
}

function extractToolKeywords(t: ToolDefinition): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  // Mismas fuentes que `toolKeywords`: nombre (identidad: familia + entidad) +
  // tags + intentSummary + description. El nombre va primero para sobrevivir al
  // tope de 12 y para que la coleccion de keywords responda a la familia y la
  // entidad —no solo al vocabulario de la prosa—; la descripcion aporta el
  // vocabulario de intencion ("crear", "listar") que distingue tools del mismo
  // complemento.
  const sources = [
    ...toolIdentityTokens(t.name ?? ""),
    ...(t.tags ?? []),
    ...(t.intentSummary ?? "").toLowerCase().split(/\s+/),
    ...(t.description ?? "").toLowerCase().split(/\s+/),
  ];
  for (const kw of sources) {
    const clean = kw.toLowerCase().trim();
    if (clean.length > 1 && !seen.has(clean)) {
      seen.add(clean);
      out.push(clean);
    }
  }
  return out.slice(0, 12);
}

/** RAKE ligero (replica KeywordExtractor del Go). */
function extractKeywordsRake(prompt: string, limit: number): string[] {
  const normalized = prompt.toLowerCase().trim();
  if (normalized === "" || [...normalized].length < 3) return [];

  const phrases = normalized.split(/[^\p{L}\p{N}_\-\s]+/u).filter(Boolean);
  const wordFreq = new Map<string, number>();
  const wordDeg = new Map<string, number>();

  for (const phrase of phrases) {
    const words: string[] = [];
    for (const w of phrase.split(/\s+/)) {
      const clean = cleanToken(w);
      if ([...clean].length <= 2) continue;
      words.push(clean);
    }
    if (words.length === 0) continue;
    const unique = [...new Set(words)];
    for (const w of words) wordFreq.set(w, (wordFreq.get(w) ?? 0) + 1);
    for (const w of unique) wordDeg.set(w, (wordDeg.get(w) ?? 0) + (unique.length - 1));
  }

  if (wordFreq.size === 0) return [];
  const list = [...wordFreq.entries()]
    .map(([w, freq]) => ({ word: w, score: freq > 0 ? (wordDeg.get(w) ?? 0) / freq : 0 }))
    .sort((a, b) => b.score - a.score);
  return list.slice(0, limit).map((s) => s.word);
}

function cleanToken(w: string): string {
  return w.replace(/^[^\p{L}\p{N}_-]+/u, "").replace(/[^\p{L}\p{N}_-]+$/u, "");
}
