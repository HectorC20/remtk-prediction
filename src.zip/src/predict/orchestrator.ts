/**
 * PredictionOrchestrator: pipeline unificado de predicción, migrado de
 * prediction_orchestrator.go + memory_orchestrator.go del server Go.
 *
 * Flujo /predict:  clasificar turno → early-exit (confirmación cacheada) →
 *                  recall Qdrant → re-rank por embeddings e5 → umbral adaptativo.
 * Flujo /memory/predict: embed → topic shift → recall Qdrant → re-rank cosine.
 */
import { EmbeddingEngineService } from "../embedding/embedding.service";
import type { AppConfig } from "../config";
import { log, warn } from "../logger";
import type { QdrantService } from "../qdrant/qdrant-service";
import type {
  FeedbackInput,
  FeedbackResult,
  PredictionInput,
  Trace,
  ToolDefinition,
} from "../shared/interfaces/domain.interface";
import type { GraphEdge, GraphPredictionResult } from "../shared/interfaces/graph.interface";
import { ConfirmationCache } from "./services/confirm-cache.service";
import {
  explicitToolNames,
  extractQueryKeywords,
  matchTokenSet,
  namedFamilies,
  toolFamily,
  toolNamesInText,
} from "./keywords";
import { Debugger } from "./helper/debugger.helper";
import { ToolGraphCacheService } from "./services/graph-cache.service";
import { KeywordService } from "./services/keyword.service";
import { LexicalProfileService } from "./services/lexical-profile.service";
import { CalibrationService } from "./services/calibration.service";
import { RerankService, topologicalSort, intentDeTanda, type RerankResult } from "./services/rerank.service";
import { SessionStateCacheService } from "./services/session-state-cache.service";
import { TurnClassifier} from "./turn-classifier";
import { JuicioService } from "../juicio/juicio.service";
import type { JuicioContext } from "../shared/interfaces/juicio.interface";
import { ChatMessage, TopicState, MemoryDefinition, MemoryPredictionInput, MemoryPredictionResult, InterestPredictionInput, InterestPredictionResult, InterestMatch } from "src/shared/interfaces/index";
import {
  BLEND_NEW,
  BLEND_PREV,
  INTEREST_INTENT_WEIGHT,
  INTEREST_MAX_ANCHORS,
  INTEREST_TOPIC_WEIGHT,
  INTEREST_TOP_MATCHES,
  MAX_HISTORY_MESSAGES,
  MAX_INTENT_CONTEXT_CHARS,
  MAX_INTENT_SEGMENTS,
  MAX_MESSAGE_CHARS,
  memoryDenialThreshold,
  PREREQUISITE_WEIGHT,
  TOPIC_SHIFT_THRESHOLD,
} from "src/shared/constants/predict";
import { DEFAULT_MEMORY_PREDICTION_LIMIT } from "src/shared/constants/qdrant";
import { TurnType } from "../shared/interfaces";
import { parseKeyRemtk, resolveScopeKey } from "src/shared/scope";

const CANONICAL_INTEREST_PROBE =
  "interés comercial en adquirir, comprar, cotizar o contratar un producto o servicio";

const CANONICAL_DENIAL_PROBES = [
  "afirmaciones del agente negando herramientas o capacidades técnicas para la tarea",
  "el asistente afirma que no tiene herramientas ni funciones disponibles para realizar la acción",
  "no tengo ninguna herramienta ni función disponible para realizar esta tarea",
];

/** Acota un score al rango [0, 1]. */
function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.min(1, Math.max(0, value));
}

export class PredictionOrchestrator {
  private readonly topics = new Map<string, TopicState>();
  private readonly memoryCache = new Map<string, Float32Array>();
  /** Embeddings de las anclas de tema (etiquetas de subgrafo de remtk-memory), cacheados por etiqueta. */
  private readonly anchorCache = new Map<string, Float32Array>();
  /** Embeddings de los arquetipos de intención (carga perezosa, una sola vez). */
  private intentEmbs?: Float32Array[];
  /** Última predicción por sesión (para la señal implícita de reformulación, §8.2). */
  private readonly lastTurns = new Map<string, { prompt: string; tools: string[] }>();

  constructor(
    private readonly engine: EmbeddingEngineService,
    private readonly qdrant: QdrantService,
    private readonly classifier: TurnClassifier,
    private readonly rerank: RerankService,
    private readonly confirmCache: ConfirmationCache,
    private readonly keywords: KeywordService,
    private readonly graphCache: ToolGraphCacheService,
    private readonly sessionState: SessionStateCacheService,
    private readonly debugger_: Debugger,
    private readonly config: AppConfig,
    private readonly lexical: LexicalProfileService,
    private readonly juicio: JuicioService,
  ) {}

  /** Warm-ups de embeddings pendientes por scopeKey (deduplicado/encadenado). */
  private readonly warmups = new Map<string, Promise<void>>();

  /**
   * POST /tools: indexa el catálogo del scope en Qdrant (sparse, rápido) y responde;
   * el cálculo de embeddings (keywords + grafo) corre en background para que un
   * scope en frío no dispare el timeout del cliente (10 s) ni aborte el turno.
   */
  async registerTools(tenant: string, tools: ToolDefinition[], agentId?: string): Promise<{ indexed: number }> {
    const scopeKey = resolveScopeKey(tenant, agentId);
    await this.qdrant.indexTools(scopeKey, tools);
    log(`[tools] tenant=${tenant} scope=${scopeKey} indexados=${tools.length} (embeddings en warm-up)`);
    this.warmScope(scopeKey, tools);
    return { indexed: tools.length };
  }

  /**
   * Dispara el warm-up de embeddings del scope sin bloquear la respuesta.
   * Si ya hay un warm-up corriendo para el mismo scope, encadena el nuevo tras él
   * (así un re-registro con más tools no se pierde por una carrera).
   */
  private warmScope(scopeKey: string, tools: ToolDefinition[]): void {
    const prev = this.warmups.get(scopeKey) ?? Promise.resolve();
    const task = prev
      .catch(() => undefined)
      .then(async () => {
        const { recomputed, cached } = await this.keywords.upsertTools(scopeKey, tools);
        await this.graphCache.buildTenantGraph(scopeKey, tools);
        // Tercer paso del warm-up: semilla del perfil léxico del canal (§7).
        // Síncrono y sin ONNX: no compite con la cola de inferencia.
        this.lexical.seedScope(scopeKey, tools);
        // La capa de juicio cachea vectores por scope (MaxSim, difusión): se
        // invalidan al re-registrar el catálogo.
        this.juicio.clearScope(scopeKey);
        this.debugger_.bump({ embeddingsRecomputed: recomputed, embeddingsCached: cached });
        this.debugger_.setTenants(this.qdrant.countTools(scopeKey) > 0 ? Math.max(1, this.debugger_.snapshot().stats.tenants) : 0);
        log(`[tools] scope=${scopeKey} warm-up completo indexados=${tools.length} embeddings recomputed=${recomputed} cached=${cached}`);
      })
      .catch((error: unknown) => {
        warn(`[tools] warm-up falló scope=${scopeKey}: ${error instanceof Error ? error.message : String(error)}`);
      })
      .finally(() => {
        // Solo limpia si sigue siendo el último warm-up encadenado.
        if (this.warmups.get(scopeKey) === task) this.warmups.delete(scopeKey);
      });
    this.warmups.set(scopeKey, task);
  }

  countTools(tenant: string, agentId?: string): number {
    return this.qdrant.countTools(resolveScopeKey(tenant, agentId));
  }

  async waitForWarmup(tenant: string, agentId?: string): Promise<void> {
    const scopeKey = resolveScopeKey(tenant, agentId);
    while (this.warmups.has(scopeKey)) {
      await this.warmups.get(scopeKey);
    }
  }

  /**
   * Variante acotada de `waitForWarmup`: espera como máximo `ms` a que concluya
   * el warm-up del scope (incluidos los encadenados por un re-registro). Devuelve
   * false si expira la cota, para que el llamador degrade de forma consciente.
   */
  async waitForWarmupBounded(scopeKey: string, ms: number): Promise<boolean> {
    const deadline = Date.now() + Math.max(0, ms);
    while (this.warmups.has(scopeKey)) {
      const remaining = deadline - Date.now();
      if (remaining <= 0) return false;
      await Promise.race([
        this.warmups.get(scopeKey)!.catch(() => undefined),
        new Promise((resolve) => setTimeout(resolve, Math.min(remaining, 200))),
      ]);
    }
    return true;
  }

  /**
   * POST /predict/feedback: aplica una señal de refuerzo al perfil léxico del
   * canal. `used` debe traer solo herramientas con éxito real (§8.1): usar "fue
   * predicha" como señal positiva realimentaría los errores del modelo.
   */
  feedback(input: FeedbackInput): FeedbackResult {
    const scopeKey = resolveScopeKey(input.tenant, input.agentId);
    const events = this.lexical.observe(
      scopeKey,
      input.text ?? "",
      input.used ?? [],
      input.rejected ?? [],
    );
    log(
      `[feedback] scope=${scopeKey} session=${input.sessionId} used=${input.used?.length ?? 0} ` +
        `rejected=${input.rejected?.length ?? 0} events=${events}`,
    );
    return { ok: true, events };
  }

  /** POST /predict */
  async predict(input: PredictionInput): Promise<GraphPredictionResult> {
    const start = Date.now();
    const trace: Trace = {
      sessionId: input.sessionId,
      tenant: input.tenant,
      turnType: TurnType.NewQuery,
      confirmHit: false,
      recall: 0,
      degraded: false,
      inputTokens: (input.text ?? "").length,
      outputTools: 0,
      modelSize: "hash",
      embeddingsRecomputed: 0,
      embeddingsCached: 0,
      complexity: "simple",
      latencyMs: 0,
      timestamp: new Date().toISOString(),
    };
    // Partición por agente: scopeKey = tenant (chat general) o `tenant::agentId`.
    const scopeKey = resolveScopeKey(input.tenant, input.agentId);
    trace.scopeKey = scopeKey;

    const text = (input.text ?? "").trim();
    if (text === "") {
      return {
        tools: [],
        complexity: "simple",
        modelSize: "hash",
        rankedScores: [],
        graph: { nodes: [], edges: [], executionOrder: [] },
        context: {
          intent: { primaryAction: "unknown", confidence: 0, summary: "Consulta vacía" },
          constraints: { negations: [], isConfirmation: false, isExploratory: false },
          dialogState: { phase: "discovery", topicShift: false },
          anticipation: { suggestedNextTools: [], reasoning: "Texto vacío" },
        },
      };
    }

    // El cache de confirmacion es estado del DIÁLOGO: lo escribe un turno humano
    // y lo consume su confirmacion ("hazlo"). Un /predict con source=agent es una
    // SUBCONSULTA por subtarea dentro del MISMO sessionId del chat: si lee el
    // cache recibe las herramientas de otra subtarea (y con ellas el resto de la
    // consulta —enriquecida o no— queda sin evaluar).
    const esAgente = input.source === "agent";
    const cachedPlan = esAgente ? undefined : this.confirmCache.get(input.sessionId);
    const hasPendingPlan = !!cachedPlan;

    // ── Capa de juicio: NLI de estado condicionado (§1) + puerta (§3) + proyección topológica ──────
    const juicioCtx: JuicioContext = await this.juicio.pre({
      scopeKey,
      sessionId: input.sessionId,
      text,
      source: input.source,
      history: input.history,
      cachedPlan,
    });
    trace.juicioGateLambda = juicioCtx.gateLambda;
    trace.juicioEstado = juicioCtx.estado;

    // Veredicto REJECT: el usuario niega la propuesta pendiente → 0 tools y el
    // plan cacheado se invalida.
    if (juicioCtx.resolvedBy === "nli_reject") {
      this.confirmCache.delete(input.sessionId);
      this.finalize(trace, start, []);
      return {
        tools: [],
        complexity: "simple",
        modelSize: "hash",
        rankedScores: [],
        graph: { nodes: [], edges: [], executionOrder: [] },
        context: {
          intent: {
            primaryAction: "unknown",
            confidence: 0.9,
            summary: "Rechazo de la propuesta pendiente (juicio NLI)",
          },
          constraints: { negations: [text], isConfirmation: false, isExploratory: false },
          dialogState: { phase: "discovery", topicShift: false },
          anticipation: { suggestedNextTools: [], reasoning: "Propuesta rechazada por el usuario" },
        },
      };
    }

    // Clasificación del turno mediante juicio topológico y estado de diálogo
    const turn = await this.classifier.classify(text, {
      hasPendingPlan,
      prominence: juicioCtx.prominence,
      isAutonomousPivot: juicioCtx.isAutonomousPivot,
      estado: juicioCtx.estado,
    });
    trace.turnType = turn;
    log(`[pipeline] predict session=${input.sessionId} tenant=${input.tenant} scope=${scopeKey} turn=${turn}`);

    // Consulta de catálogo o meta-pregunta sobre capacidades del sistema
    const isMeta = await this.classifier.isMetaQuestion(text);
    const isCatalog = !isMeta && (await this.classifier.isCatalogInquiry(text));
    const catalog = this.qdrant.catalog(scopeKey);
    const allTools = catalog.all();
    let queryTokens = matchTokenSet(text);
    const families = namedFamilies(queryTokens, allTools.map((t) => t.name));

    if (isMeta || (isCatalog && families.size > 0)) {
      if (families.size > 0) {
        // Retornamos todas las herramientas registradas de esa familia
        const familyTools = allTools.filter((t) => {
          const fam = toolFamily(t.name);
          return fam && families.has(fam);
        });
        if (familyTools.length > 0 && familyTools.length <= this.config.maxOutputTools) {
          log(`[pipeline] consulta de catálogo con familia=[${[...families].join(",")}] → devolviendo ${familyTools.length} tools`);
          this.finalize(trace, start, familyTools.map((t) => t.name));
          return {
            tools: familyTools,
            complexity: "simple",
            modelSize: this.engine.defaultSize,
            rankedScores: familyTools.map(() => 1.0),
            calibratedScores: familyTools.map(() => 0.98),
            graph: { nodes: familyTools.map((t) => t.name), edges: [], executionOrder: familyTools.map((t) => t.name) },
            context: {
              intent: {
                primaryAction: "meta",
                confidence: 0.98,
                ...intentDeTanda(familyTools),
                summary: `Herramientas de la familia ${[...families].join(", ")}`,
              },
              constraints: { negations: [], isConfirmation: false, isExploratory: true },
              dialogState: { phase: "discovery", topicShift: false },
              anticipation: { suggestedNextTools: [], reasoning: "Catálogo de familia solicitado" },
            },
          };
        }
      }

      if (input.source === "human" && isMeta) {
        log(`[pipeline] early-exit: meta-pregunta general (capacidades) → 0 tools`);
        this.finalize(trace, start, []);
        return {
          tools: [],
          complexity: "simple",
          modelSize: "hash",
          rankedScores: [],
          calibratedScores: [],
          graph: { nodes: [], edges: [], executionOrder: [] },
          context: {
            intent: {
              primaryAction: "meta",
              confidence: 0.95,
              summary: "Pregunta sobre capacidades del sistema",
            },
            constraints: { negations: [], isConfirmation: false, isExploratory: true },
            dialogState: { phase: "discovery", topicShift: false },
            anticipation: { suggestedNextTools: [], reasoning: "Meta-pregunta resuelta sin herramientas" },
          },
        };
      }
    }

    // Early exit: confirmación con plan cacheado previo (empty o nli_confirm).
    // Solo de un turno HUMANO: un /predict de agente trae su propia subtarea y
    // debe juzgarse con ella.
    if (!esAgente && (turn === TurnType.ConfirmationEmpty || juicioCtx.resolvedBy === "nli_confirm")) {
      this.debugger_.bump({ confirmGets: 1 });
      const cached = cachedPlan ?? this.confirmCache.get(input.sessionId);
      if (cached) {
        trace.confirmHit = true;
        this.debugger_.bump({ confirmHits: 1 });
        log(`[pipeline] early-exit: confirmación con plan cacheado`);
        this.finalize(trace, start, cached.tools.map((t) => t.name));
        return cached;
      }
    }

    // En turnos de confirmación (con matiz) o source=agent se predice sobre el plan previo.
    // En consulta nueva se incorporan los mensajes previos para dar contexto —
    // salvo que la puerta de coherencia (juicio §3) haya aislado el turno:
    // ahí el historial contaminaría el ranking (caso cambio-tema).
    // Las `keywords` delegadas (planificador/cliente) se anexan a la consulta:
    // alimentan el match cross-idioma (capa 2), el recall BM25 y el z_t de sesión.
    const effectiveText = juicioCtx.focusedText ?? text;
    const isAutonomous = juicioCtx.isAutonomousPivot === true;
    const needsHistory = !juicioCtx.historyGated || !isAutonomous;
    // Enriquecimiento interno del consumidor (pre-pensamiento del planificador):
    // ensancha la búsqueda SIN tocar `text`, que sigue siendo lo que se pidió. El
    // bloque describe TODO el plan, así que se queda con los segmentos que más se
    // pegan a esta consulta (ver `segmentosRelevantesDeIntent`) y entra solo por
    // el recall léxico, nunca por el vector de la subtarea.
    const intentText = await this.segmentosRelevantesDeIntent(
      effectiveText,
      input.intentContext,
    );
    if (intentText) trace.intentContextChars = intentText.length;
    const baseText =
      turn === TurnType.NewQuery
        ? needsHistory
          ? this.withHistory(effectiveText, input.history)
          : effectiveText
        : input.priorPlan ?? this.withHistory(effectiveText, input.history);
    const promptText = this.withKeywords(baseText, input.keywords);
    // Consulta con la que se BUSCA cuando hay enriquecimiento. No es la consulta
    // con la que se PUNTÚA: `promptText`, su vector y sus tokens mandan, así que
    // el bloque puede traer candidatas pero no moverle el lugar a ninguna
    // (ver `recallAmpliado`).
    const lexicalText = intentText ? `${promptText}\n${intentText}` : promptText;

    // Tokens de match de la consulta (incluidas las keywords delegadas): son la
    // señal con la que el rerank mide la afinidad contra el NOMBRE de cada
    // herramienta, lo único que distingue familias dentro de un complemento.
    queryTokens = matchTokenSet(promptText);

    // Herramientas nombradas EXPLÍCITAMENTE: en las palabras clave delegadas
    // (orden del planificador) o LITERALMENTE en el propio turno. En ambos casos
    // el rerank las fija al frente de la salida y garantiza su presencia. Sin
    // este ancla el score por embeddings no distingue el verbo del nombre
    // (`mitumbes_item_crear` y `mitumbes_item_actualizar` comparten identidad) y,
    // cuando la descripción de una hermana menciona a la otra, la pedida queda
    // fuera de la banda: `mitumbes_item_imagen_actualizar` nombra a
    // `..._imagen_adjuntar` en su descripción y el re-rank la adelanta.
    const catalogNames = catalog.all().map((t) => t.name);
    const pinnedNames = [
      ...explicitToolNames(input.keywords, catalogNames),
      ...toolNamesInText(text, catalogNames),
    ];
    if (pinnedNames.length > 0) {
      log(`[pipeline] tools explícitas=${pinnedNames.join(",")}`);
    }

    // Estado latente de sesión (z_t): proyección suavizada del prompt entrante.
    // Con λ de juicio la mezcla es adaptativa (puerta de coherencia, §3).
    let zt: Float32Array | undefined;
    let sessionModel = "hash";
    let topicShift = false;
    let topicSim: number | undefined;
    try {
      const s = await this.sessionState.resolve(input.sessionId, promptText, juicioCtx.gateLambda);
      zt = s.zt;
      sessionModel = s.model;
      topicShift = s.topicShift;
      topicSim = s.topicSim;
    } catch (err) {
      warn(`[pipeline] estado de sesión degradado: ${String((err as Error)?.message ?? err)}`);
    }
    // Un /predict de agente es una SUBCONSULTA por subtarea dentro del MISMO
    // sessionId del chat, y el suavizado 70/30 de z_t le heredaría el tema de las
    // OTRAS subtareas del plan. Medido en `agent-secuencia-imagen.test.mjs`: la
    // subtarea de escritura, séptima llamada de la sesión, perdía a
    // `mitumbes_item_imagen_adjuntar` en la tanda por esa herencia y no por su
    // consulta —en sesión fresca el mismo texto la devuelve primera—. La
    // subconsulta se basta: se juzga por su propio vector.
    if (esAgente) {
      try {
        const fresco = await this.engine.embedQuery(promptText, undefined, { high: true });
        zt = EmbeddingEngineService.normalizeL2(fresco.embedding);
      } catch (err) {
        warn(`[pipeline] subconsulta sin estado fresco: ${String((err as Error)?.message ?? err)}`);
      }
    }

    // Warm-up en vuelo: `POST /tools` responde indexando y construye el grafo en
    // background. Sin esta espera (acotada), el primer turno de un catálogo frío
    // caería a la ruta plana y entregaría la mutación sin sus antecedentes.
    if (!this.graphCache.get(scopeKey) && this.warmups.has(scopeKey)) {
      const warmed = await this.waitForWarmupBounded(scopeKey, this.config.predictWarmupWaitMs);
      if (!warmed) {
        trace.warmupWaitTimeout = true;
        warn(
          `[pipeline] warm-up scope=${scopeKey} no concluyó en ${this.config.predictWarmupWaitMs}ms → ` +
            `ruta plana (pre-plan DAG solo por prerequisites declaradas)`,
        );
      }
    }

    const graph = this.graphCache.get(scopeKey);

    // Ruta topológica: el grafo del scope está precomputado en POST /tools.
    if (graph && zt) {
      const { scores: lexicalScores, agregadas } = await this.recallAmpliado(
        scopeKey,
        promptText,
        lexicalText,
      );
      if (agregadas) trace.intentPoolAdded = agregadas;
      const learned = this.lexical.score(scopeKey, promptText);
      const raw = this.rerank.graphFilter({
        zt,
        graph,
        edges: this.graphCache.edges(scopeKey),
        lexicalScores,
        learned,
        catalog,
        modelSize: sessionModel,
        exclude: input.exclude,
        queryTokens,
        pinnedNames,
        topicShift,
        turnType: turn,
        source: input.source,
      });
      // Capa de juicio (post): abstención + re-rank del top-K. Las órdenes
      // explícitas (pinned por keywords) no se juzgan: las mandó el planificador.
      const result = await this.judgeResult(scopeKey, effectiveText, juicioCtx, raw, pinnedNames, trace, input.exclude, input.source);
      trace.recall = graph.nodes.size;
      trace.modelSize = result.modelSize;
      trace.complexity = result.complexity;
      trace.outputTools = result.tools.length;
      trace.embeddingsCached = graph.nodes.size;
      trace.learnWeight = learned.weight;
      trace.learnTerms = learned.scores.size;
      this.debugger_.bump({ embeddingsCached: graph.nodes.size });

      if (result.tools.length > 0 && !esAgente) {
        this.confirmCache.set(input.sessionId, result);
        this.debugger_.bump({ confirmSets: 1 });
      }

      this.trackTurn({
        input,
        turn,
        topicSim,
        scopeKey,
        promptText,
        tools: result.tools.map((t) => t.name),
      });
      this.finalize(trace, start, result.tools.map((t) => t.name));
      return result;
    }

    // Fallback plano (sin grafo): reduce por keywords + fusión BM25.
    let reduced: { name: string; score: number }[] = [];
    let modelSize = "hash";
    let recomputed = 0;
    let cached = 0;
    try {
      const r = await this.keywords.reduce(scopeKey, promptText, this.qdrant.catalog(scopeKey));
      reduced = r.candidates;
      modelSize = r.modelSize;
      recomputed = r.recomputed;
      cached = r.cached;
      // La ruta plana NO amplía el pool con `intentContext`: aquí `reduce` elige y
      // puntúa a la vez, así que recuperar con el bloque reescribiría el ranking de
      // la consulta (lo que `recallAmpliado` evita en la topológica). Una
      // subconsulta de agente llega caliente al grafo; esta es la ruta degradada.
    } catch (err) {
      warn(`[pipeline] keyword reduce degradado: ${String((err as Error)?.message ?? err)}`);
    }
    trace.degraded = reduced.length === 0;
    if (trace.degraded) {
      reduced = this.qdrant.catalog(scopeKey).all().map((t) => ({ name: t.name, score: 0 }));
    }
    trace.recall = reduced.length;
    log(`[pipeline] reduce candidates=${reduced.length} degraded=${trace.degraded}`);

    const lexicalScores = await this.lexicalScores(scopeKey, promptText);
    const learned = this.lexical.score(scopeKey, promptText);
    const base = this.rerank.filter(
      reduced,
      lexicalScores,
      learned,
      catalog,
      modelSize,
      input.exclude,
      queryTokens,
      pinnedNames,
    );
    // Ruta plana: no hay grafo precomputado, así que el pre-plan DAG se repone con
    // las pre-relaciones DECLARADAS del catálogo. Sin esto un catálogo frío (o un
    // warm-up que agotó su cota) entrega la mutación sola y el ejecutor tiene que
    // adivinar los listados que le dan los identificadores.
    const flat = this.withDeclaredPrerequisites(base, catalog, input.exclude);
    // Capa de juicio (post), igual que en la ruta topológica.
    const result = await this.judgeResult(
      scopeKey,
      effectiveText,
      juicioCtx,
      flat,
      pinnedNames,
      trace,
      input.exclude,
      input.source,
    );
    trace.embeddingsRecomputed = recomputed;
    trace.embeddingsCached = cached;
    trace.learnWeight = learned.weight;
    trace.learnTerms = learned.scores.size;
    this.debugger_.bump({ embeddingsRecomputed: recomputed, embeddingsCached: cached });
    trace.modelSize = result.modelSize;
    trace.complexity = result.complexity;
    trace.outputTools = result.tools.length;

    // Cachea el plan para confirmaciones posteriores de la sesión (solo turnos
    // humanos: el plan de una subtarea no es estado del diálogo).
    if (result.tools.length > 0 && !esAgente) {
      this.confirmCache.set(input.sessionId, result);
      this.debugger_.bump({ confirmSets: 1 });
    }

    this.trackTurn({
      input,
      turn,
      topicSim,
      scopeKey,
      promptText,
      tools: result.tools.map((t) => t.name),
    });
    this.finalize(trace, start, result.tools.map((t) => t.name));
    return result;
  }

  /**
   * Repone el pre-plan DAG en la ruta plana: cierra la selección sobre las
   * pre-relaciones DECLARADAS por el catálogo (`ToolDefinition.prerequisites`),
   * sin embeddings ni señales léxicas, y publica aristas PREREQUISITE + orden
   * topológico para que el consumidor ejecute los antecedentes primero.
   */
  private withDeclaredPrerequisites(
    base: RerankResult,
    catalog: { get(name: string): ToolDefinition | undefined },
    exclude?: string[],
  ): GraphPredictionResult {
    const excluded = new Set((exclude ?? []).map((n) => n.toLowerCase()));
    const byName = new Map<string, ToolDefinition>();
    const scoreByName = new Map<string, number>();
    base.tools.forEach((t, i) => {
      byName.set(t.name, t);
      scoreByName.set(t.name, base.rankedScores[i] ?? 0);
    });

    const edges: GraphEdge[] = [];
    const seenEdges = new Set<string>();
    const ceiling = this.config.maxOutputTools;
    const queue = base.tools.map((t) => t.name);
    const visited = new Set<string>();
    while (queue.length > 0) {
      const name = queue.shift()!;
      if (visited.has(name)) continue;
      visited.add(name);
      for (const raw of catalog.get(name)?.prerequisites ?? []) {
        const pre = catalog.get(raw);
        if (!pre || excluded.has(pre.name.toLowerCase()) || pre.name === name) continue;
        const edge = `${pre.name}→${name}`;
        if (!byName.has(pre.name)) {
          if (byName.size >= ceiling) continue;
          // Misma cota que la propagación del grafo (PREREQUISITE_WEIGHT): el
          // antecedente entra dentro de la banda del top, no como relleno.
          byName.set(pre.name, pre);
          scoreByName.set(pre.name, PREREQUISITE_WEIGHT);
          queue.push(pre.name);
        }
        if (!seenEdges.has(edge)) {
          seenEdges.add(edge);
          edges.push({ from: pre.name, to: name, type: "PREREQUISITE", weight: PREREQUISITE_WEIGHT });
        }
      }
    }

    const order = topologicalSort([...byName.keys()], edges, scoreByName);
    const tools = order.map((n) => byName.get(n)!);
    const rankedScores = order.map((n) => scoreByName.get(n) ?? 0);
    if (edges.length > 0) {
      log(`[pipeline] ruta plana pre-plan: antecedentes=${edges.length} salida=${tools.length}`);
    }
    return {
      ...base,
      tools,
      rankedScores,
      calibratedScores: CalibrationService.calibrateRankedScores(rankedScores),
      graph: { nodes: order, edges, executionOrder: order },
    };
  }

  /**
   * Post de juicio sobre el resultado del rerank (abstención + re-rank top-K).
   * Las herramientas fijadas explícitamente por keywords del planificador no se
   * juzgan: son una orden directa, no una hipótesis.
   */
  private async judgeResult(
    scopeKey: string,
    text: string,
    ctx: JuicioContext,
    result: GraphPredictionResult,
    pinnedNames: string[],
    trace: Trace,
    exclude?: string[],
    source?: "human" | "agent",
  ): Promise<GraphPredictionResult> {
    if (pinnedNames.length > 0) return result;
    const judged = await this.juicio.post({ scopeKey, text, ctx, result, exclude, source });
    if (judged.diag.abstained) trace.juicioAbstained = judged.diag.abstainReason;
    trace.juicioNoopScore = judged.diag.noopScore;
    trace.juicioEnergy = judged.diag.energy;
    trace.juicioSignals = {
      maxsim: judged.diag.maxsimApplied,
      reranker: judged.diag.rerankerApplied,
      specificity: judged.diag.specificityApplied,
    };
    return judged.result;
  }

  /**
   * Señal implícita (§8.2): cuando un turno humano abre tema nuevo de verdad
   * (coseno contra z_{t-1} por debajo de TOPIC_SHIFT_THRESHOLD) y las herramientas
   * predichas en el turno anterior ya no reaparecen en la consulta, se penaliza
   * débilmente la asociación término→herramienta que llevó a ellas ("el usuario
   * reformuló porque no era eso"). Se apoya en el estado de sesión que ya existe:
   * no requiere cambios en el consumidor.
   */
  private trackTurn(params: {
    input: PredictionInput;
    turn: TurnType;
    topicSim?: number;
    scopeKey: string;
    promptText: string;
    tools: string[];
  }): void {
    const sessionId = params.input.sessionId;
    if (!sessionId) return;
    const prev = this.lastTurns.get(sessionId);
    // `topicShift` también la dispara la puerta de coherencia (λ) para aislar el
    // turno del historial, sin que el usuario haya cambiado de tema. Solo el
    // cosine contra z_{t-1} es evidencia de reformulación: sin esa comprobación
    // el turno siguiente del MISMO objetivo llegaba penalizado por canal.
    const drifted = params.topicSim !== undefined && params.topicSim < TOPIC_SHIFT_THRESHOLD;
    if (
      prev &&
      params.input.source === "human" &&
      params.turn === TurnType.NewQuery &&
      drifted &&
      prev.tools.length > 0 &&
      !this.toolMentioned(prev.tools, params.promptText)
    ) {
      // `observe` sin `used` solo resta: es la penalización débil de la señal
      // implícita, nunca un refuerzo (no hubo éxito confirmado).
      this.lexical.observe(params.scopeKey, prev.prompt, [], prev.tools);
      log(
        `[pipeline] señal implícita: reformulación session=${sessionId} → penalizadas ` +
          `${prev.tools.length} tools del turno anterior`,
      );
    }
    this.lastTurns.set(sessionId, { prompt: params.promptText, tools: params.tools });
  }

  /** True si alguna herramienta reaparece (nombre literal o keyword) en el texto. */
  private toolMentioned(tools: string[], promptText: string): boolean {
    const lowered = promptText.toLowerCase();
    const terms = new Set(extractQueryKeywords(promptText));
    return tools.some((name) => {
      if (lowered.includes(name.toLowerCase())) return true;
      return extractQueryKeywords(name).some((term) => terms.has(term));
    });
  }

  /** Confirmación léxica BM25 (normalizada 0..1) para reforzar el score semántico. */
  private async lexicalScores(tenant: string, promptText: string): Promise<Map<string, number>> {
    const scores = new Map<string, number>();
    try {
      const lexical = await this.qdrant.retrieveTools(tenant, promptText, this.config.recallLimit);
      const maxLex = lexical.reduce((m, l) => Math.max(m, l.score), 0);
      for (const l of lexical) {
        scores.set(l.name, maxLex > 0 ? l.score / maxLex : 0);
      }
    } catch (err) {
      warn(`[pipeline] confirm léxica degradada: ${String((err as Error)?.message ?? err)}`);
    }
    return scores;
  }

  /**
   * Pool de candidatas con el enriquecimiento interno ya aplicado, por UNIÓN
   * estrictamente aditiva: lo que el bloque recupera entra SOLO donde la consulta
   * cruda no trajo nada, con su propio score y sin tocar a las ya presentes.
   *
   * Medido con el catálogo real y la subtarea de escritura de
   * `nest-2026-09-28 (3).log`: recuperar con el bloque enriquecido y mezclar los
   * scores por máximo reordenaba a las ya presentes (`mitumbes_item_crear`
   * 1.134→1.148), la normalización del pool cambiaba y la selección dejaba de
   * 5 a 4 botando justamente `mitumbes_item_imagen_adjuntar`. El bloque describe
   * TODO el plan, así que su búsqueda es otra consulta: amplía el pool, no
   * reescribe el ranking de la consulta real.
   */
  private async recallAmpliado(
    scopeKey: string,
    promptText: string,
    lexicalText: string,
  ): Promise<{ scores: Map<string, number>; agregadas: number }> {
    const scores = await this.lexicalScores(scopeKey, promptText);
    if (lexicalText === promptText) return { scores, agregadas: 0 };
    const ampliada = await this.lexicalScores(scopeKey, lexicalText);
    let agregadas = 0;
    for (const [name, score] of ampliada) {
      if (scores.has(name)) continue;
      scores.set(name, score);
      agregadas++;
    }
    log(`[intentContext] pool=${scores.size} agregadas=${agregadas}`);
    return { scores, agregadas };
  }

  /** POST /memory/predict: memorias contextuales + detección de cambio de tema. */
  async predictMemory(input: MemoryPredictionInput): Promise<MemoryPredictionResult> {
    const text = (input.text ?? "").trim();
    if (text === "") {
      return { memories: [], topicShift: false, topicScore: 0, modelSize: "hash", rankedScores: [] };
    }

    const promptEmb = await this.engine.embedQuery(text);
    log(`[memory] embedded model=${promptEmb.model} dim=${promptEmb.dim}`);

    // Detección de cambio de tema por cosine contra el estado previo de la sesión.
    let topicScore = 0;
    let shift = false;
    const prev = this.topics.get(input.sessionId);
    if (prev) {
      topicScore = EmbeddingEngineService.cosine(promptEmb.embedding, prev.embedding);
      shift = topicScore < TOPIC_SHIFT_THRESHOLD;
    }
    this.topics.set(input.sessionId, this.updateTopic(prev, promptEmb.embedding, shift));

    const { tenant, agentId } = parseKeyRemtk(input.keyRemtk, input.tenant, input.agentId);

    // Recall BM25 directo en Qdrant (degradación suave si no responde).
    let candidates: { memory: MemoryDefinition; retrievalScore: number }[] = [];
    try {
      candidates = await this.qdrant.searchMemories(
        tenant,
        text,
        input.limit || DEFAULT_MEMORY_PREDICTION_LIMIT,
        agentId,
      );
    } catch (err) {
      log(`[memory] recall degradado (Qdrant no disponible): ${String((err as Error)?.message ?? err)}`);
      candidates = [];
    }

    // Re-rank: cosine entre prompt y cada memoria (embeddings cacheados por content).
    const scored = [];
    for (const c of candidates) {
      const emb = await this.memoryEmbedding(c.memory.content);
      if (!emb) {
        scored.push({ memory: { ...c.memory, score: c.retrievalScore }, score: c.retrievalScore });
        continue;
      }
      const s = EmbeddingEngineService.cosine(promptEmb.embedding, emb);
      scored.push({ memory: { ...c.memory, score: s }, score: s });
    }
    scored.sort((a, b) => b.score - a.score);

    const result: MemoryPredictionResult = {
      memories: scored.map((s) => s.memory),
      topicShift: shift,
      topicScore,
      modelSize: promptEmb.model,
      rankedScores: scored.map((s) => s.score),
    };
    log(`[memory] memories=${result.memories.length} topicShift=${shift} topicScore=${topicScore.toFixed(3)}`);
    return result;
  }

  /**
   * POST /interest: score semántico de interés del turno, sin regex ni diccionario
   * de idioma. Combina (1) intención —coseno máximo contra arquetipos embebidos—
   * y (2) tema —coseno contra las anclas de interés que remtk-memory descubrió por
   * datos. El predictor solo mide similitud; el umbral de escalado lo aplica quien llama.
   */
  async predictInterest(input: InterestPredictionInput): Promise<InterestPredictionResult> {
    const text = (input.text ?? "").trim();
    const anchors = this.normalizeAnchors(input.anchors, input.limit);
    if (text === "") {
      return { interestScore: 0, topic: null, topicScore: 0, intentScore: 0, matches: [], method: "empty" };
    }

    const promptEmb = await this.engine.embedQuery(text, this.engine.defaultSize, { high: true });
    const intentScore = await this.intentScore(promptEmb.embedding);
    const matches = await this.topicMatches(promptEmb.embedding, anchors);
    const topicScore = matches.length ? matches[0].score : 0;
    const topic = matches.length ? matches[0].anchor : null;

    // Con anclas: mezcla tema+intención. Sin anclas (grafo aún sin descubrir):
    // cae a intención pura para no perder la señal.
    const interestScore = matches.length
      ? clamp01(topicScore * INTEREST_TOPIC_WEIGHT + intentScore * INTEREST_INTENT_WEIGHT)
      : clamp01(intentScore);

    log(
      `[interest] session=${input.sessionId} scope=${resolveScopeKey(input.tenant, input.agentId)} ` +
        `intent=${intentScore.toFixed(3)} topic=${topicScore.toFixed(3)} score=${interestScore.toFixed(3)} ` +
        `anchors=${anchors.length} model=${promptEmb.model}`,
    );

    return {
      interestScore,
      topic,
      topicScore,
      intentScore,
      matches: matches.slice(0, INTEREST_TOP_MATCHES),
      method: promptEmb.model,
    };
  }

  /** Coseno máximo del turno contra los arquetipos de intención (multi-idioma, sin regex). */
  private async intentScore(embedding: Float32Array): Promise<number> {
    const embs = await this.ensureIntentEmbs();
    let max = 0;
    for (const emb of embs) {
      const s = EmbeddingEngineService.cosine(embedding, emb);
      if (s > max) max = s;
    }
    return max;
  }

  private async ensureIntentEmbs(): Promise<Float32Array[]> {
    if (this.intentEmbs) return this.intentEmbs;
    const res = await this.engine.embedQuery(CANONICAL_INTEREST_PROBE, this.engine.defaultSize);
    this.intentEmbs = [res.embedding];
    return this.intentEmbs;
  }

  private denialEmbs?: Float32Array[];

  private async ensureDenialEmbs(): Promise<Float32Array[]> {
    if (this.denialEmbs) return this.denialEmbs;
    const embs: Float32Array[] = [];
    for (const p of CANONICAL_DENIAL_PROBES) {
      const res = await this.engine.embedQuery(p, this.engine.defaultSize);
      embs.push(res.embedding);
    }
    this.denialEmbs = embs;
    return this.denialEmbs;
  }

  /**
   * Juicio semántico sobre hechos o texto para memoria contextual sin diccionarios ni regex.
   * Determina si un texto representa ruido de negación de herramientas o limitaciones técnicas
   * no aptas para persistir en memoria contextual de largo plazo.
   */
  async judgeMemory(text: string): Promise<{ isNoise: boolean; noiseScore: number }> {
    const trimmed = String(text ?? "").trim();
    if (!trimmed) return { isNoise: false, noiseScore: 0 };

    // Mensajes atribuidos directamente al usuario o historial de turnos nunca se catalogan como negaciones técnicas
    if (
      trimmed.startsWith("Prompt del usuario:") ||
      trimmed.startsWith("[HISTORIAL RECIENTE]") ||
      trimmed.startsWith("user:")
    ) {
      log(`[memory:judge] text="${trimmed.slice(0, 50)}" score=0.000 isNoise=false (origen usuario preservado)`);
      return { isNoise: false, noiseScore: 0 };
    }

    const embs = await this.ensureDenialEmbs();
    const promptEmb = await this.engine.embedQuery(trimmed, this.engine.defaultSize, { high: true });
    let max = 0;
    for (const emb of embs) {
      const s = EmbeddingEngineService.cosine(promptEmb.embedding, emb);
      if (s > max) max = s;
    }
    const isNoise = max >= memoryDenialThreshold[this.engine.defaultSize];
    log(`[memory:judge] text="${trimmed.slice(0, 50)}" score=${max.toFixed(3)} isNoise=${isNoise}`);
    return { isNoise, noiseScore: max };
  }

  /** Coseno del turno contra cada ancla, ordenado desc. */
  private async topicMatches(embedding: Float32Array, anchors: string[]): Promise<InterestMatch[]> {
    const out: InterestMatch[] = [];
    for (const anchor of anchors) {
      const emb = await this.anchorEmbedding(anchor);
      if (!emb) continue;
      out.push({ anchor, score: EmbeddingEngineService.cosine(embedding, emb) });
    }
    out.sort((a, b) => b.score - a.score);
    return out;
  }

  private async anchorEmbedding(anchor: string): Promise<Float32Array | undefined> {
    const key = anchor.trim().toLowerCase();
    if (key === "") return undefined;
    const cached = this.anchorCache.get(key);
    if (cached) return cached;
    const res = await this.engine.embedPassage(anchor, this.engine.defaultSize, { high: true });
    this.anchorCache.set(key, res.embedding);
    return res.embedding;
  }

  /** Normaliza/deduplica las anclas recibidas (tope INTEREST_MAX_ANCHORS). */
  private normalizeAnchors(anchors: unknown, limit?: number): string[] {
    if (!Array.isArray(anchors)) return [];
    const cap =
      Number.isFinite(Number(limit)) && Number(limit) > 0
        ? Number(limit)
        : INTEREST_MAX_ANCHORS;
    const seen = new Set<string>();
    const out: string[] = [];
    for (const a of anchors) {
      if (typeof a !== "string") continue;
      const v = a.trim();
      if (v === "") continue;
      const k = v.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(v);
      if (out.length >= cap) break;
    }
    return out;
  }

  /**
   * Incorpora los mensajes previos al texto actual para dar contexto a la
   * extracción de keywords y al match (capa 1+2). Recorta a los últimos mensajes.
   */
  private withHistory(text: string, history?: ChatMessage[]): string {
    if (!history || history.length === 0) return text;
    const recent = history
      .slice(-MAX_HISTORY_MESSAGES)
      .map((m) => (m?.content ?? "").trim())
      .filter((c) => c.length > 0)
      .map((c) => (c.length > MAX_MESSAGE_CHARS ? c.slice(0, MAX_MESSAGE_CHARS) : c));
    if (recent.length === 0) return text;
    return [...recent, text].join("\n");
  }

  /** Embeddings de segmentos ya puntuados (el mismo plan se consulta por N subtareas). */
  private readonly intentSegmentCache = new Map<string, Float32Array>();

  /**
   * Recorta el pre-pensamiento del planificador a los segmentos que más se
   * pegan a ESTA consulta y los acota.
   *
   * No es un corte por similitud absoluta: medido con el catálogo real, un
   * segmento que habla de OTRA subtarea puntúa en la misma banda (0.83-0.87) que
   * uno que habla de ésta (0.83-0.93), así que un umbral fijo no filtraría nada.
   * Se conservan los MAX_INTENT_SEGMENTS mejores, que es lo que evita que un
   * bloque de todo el plan se vuelva el tema dominante de la consulta.
   *
   * La división del bloque es estructural (salto de línea o fin de oración); la
   * decisión de qué aporta es vectorial —no hay palabras clave ni diccionarios—.
   */
  private async segmentosRelevantesDeIntent(
    consulta: string,
    raw?: string,
  ): Promise<string> {
    const bloque = (raw ?? "").trim().slice(0, MAX_INTENT_CONTEXT_CHARS);
    if (!bloque) return "";
    const segmentos = bloque
      .split(/\n+|(?<=[.!?])\s+(?=\S)/)
      .map((s) => s.replace(/\s+/g, " ").trim())
      .filter((s) => s.length >= 12);
    if (segmentos.length === 0) return "";
    // Un bloque de una sola idea no tiene nada que seleccionar: se usa tal cual.
    if (segmentos.length === 1) return segmentos[0].slice(0, MAX_INTENT_CONTEXT_CHARS);

    try {
      const q = await this.engine.embedQuery(consulta, undefined, { high: true });
      const puntuados: { texto: string; sim: number }[] = [];
      for (const s of segmentos) {
        let emb = this.intentSegmentCache.get(s);
        if (!emb) {
          emb = (await this.engine.embedPassage(s, undefined, { high: true })).embedding;
          if (this.intentSegmentCache.size > 400) this.intentSegmentCache.clear();
          this.intentSegmentCache.set(s, emb);
        }
        puntuados.push({ texto: s, sim: EmbeddingEngineService.cosine(q.embedding, emb) });
      }
      const elegidos = puntuados.sort((a, b) => b.sim - a.sim).slice(0, MAX_INTENT_SEGMENTS);
      log(
        `[intentContext] segmentos=${segmentos.length} conservados=${elegidos.length} | ` +
          puntuados.map((p) => `${p.sim.toFixed(3)}:${p.texto.slice(0, 40)}`).join(" | "),
      );
      if (elegidos.length === 0) return "";
      let presupuesto = MAX_INTENT_CONTEXT_CHARS;
      const partes: string[] = [];
      for (const e of elegidos) {
        if (e.texto.length > presupuesto) break;
        partes.push(e.texto);
        presupuesto -= e.texto.length;
      }
      return partes.join(" ");
    } catch (err) {
      warn(`[intentContext] selección degradada: ${String((err as Error)?.message ?? err)}`);
      return "";
    }
  }

  /**
   * Anexa a la consulta las palabras clave delegadas (planificador o cliente).
   * Se normalizan y deduplican; sin keywords la consulta queda intacta.
   */
  private withKeywords(text: string, keywords?: string[]): string {
    if (!keywords || keywords.length === 0) return text;
    const seen = new Set<string>();
    const parts: string[] = [];
    for (const k of keywords) {
      if (typeof k !== "string") continue;
      const v = k.trim();
      if (v === "") continue;
      const key = v.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      parts.push(v);
    }
    if (parts.length === 0) return text;
    log(`[pipeline] keywords delegadas=${parts.length}`);
    return `${text}\n${parts.join(" ")}`;
  }

  private async memoryEmbedding(content: string): Promise<Float32Array | undefined> {
    if (!content) return undefined;
    const cached = this.memoryCache.get(content);
    if (cached) return cached;
    const res = await this.engine.embedPassage(content, undefined, { high: true });
    this.memoryCache.set(content, res.embedding);
    return res.embedding;
  }

  private updateTopic(prev: TopicState | undefined, emb: Float32Array, shift: boolean): TopicState {
    if (!prev) return { embedding: emb, lastScore: 0 };
    if (shift) return { embedding: emb, lastScore: 0 };
    // Sin cambio de tema: suaviza el estado con el nuevo embedding (blend 70/30).
    const blended = new Float32Array(emb.length);
    for (let i = 0; i < emb.length; i++) {
      blended[i] = prev.embedding[i] * BLEND_PREV + emb[i] * BLEND_NEW;
    }
    return { embedding: EmbeddingEngineService.normalizeL2(blended), lastScore: 0 };
  }

  private finalize(trace: Trace, start: number, outTools: string[] = []): void {
    trace.latencyMs = Date.now() - start;
    this.debugger_.addTrace(trace);
    const outNames = outTools.length ? ` out_tools=${outTools.join(",")}` : "";
    log(
      `[pipeline] predict session=${trace.sessionId} tenant=${trace.tenant} turn=${trace.turnType} ` +
        `confirm_hit=${trace.confirmHit} recall=${trace.recall} degraded=${trace.degraded} ` +
        `in=${trace.inputTokens} out=${trace.outputTools}${outNames} model=${trace.modelSize} ` +
        `emb_compute=${trace.embeddingsRecomputed} emb_cached=${trace.embeddingsCached} ` +
        `complexity=${trace.complexity} ${trace.latencyMs}ms`,
    );
  }
}
