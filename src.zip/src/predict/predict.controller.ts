/**
 * API de Predicción (puerto 6776) — controlador Nest.
 *
 * Contratos 1:1 con el server Go original (migrado de predict-server.service.ts):
 * /predict, /tools, /tools/count, /memory/predict, /health, /debug. Sin prefijo
 * global: mismos paths raíz que el listener Express original.
 *
 * PredictAppModule expone el contexto (orquestador + engine + debugger) bajo el
 * token PREDICT_CONTEXT; el motor se inyecta con @Inject explícito porque tsx/
 * esbuild no emite design:paramtypes.
 */
import "reflect-metadata";
import {
  BadRequestException,
  Body,
  Controller,
  Get,
  HttpCode,
  Inject,
  InternalServerErrorException,
  Post,
  Query,
} from "@nestjs/common";
import type { EmbeddingEngineService } from "../embedding/embedding.service";
import type { Debugger } from "./helper/debugger.helper";
import type { LexicalProfileService } from "./services/lexical-profile.service";
import type { ToolDefinition } from "../shared/interfaces/domain.interface";
import type { IPredictionOrchestrator } from "../shared/interfaces/orchestrator.interface";
import type { SpatialPredictDto, VisualToolPayload } from "src/shared/interfaces";
import { SpatialPredictService } from "./services/spatial-predict.service";
import { normalizeAgentId, resolveScopeKey } from "../shared/scope";

/** Contexto que necesita este controlador (provisto por PredictAppModule). */
export interface PredictContext {
  orchestrator: IPredictionOrchestrator;
  engine: EmbeddingEngineService;
  debugger: Debugger;
  lexical: LexicalProfileService;
  spatial?: SpatialPredictService;
}

/** Token de inyección del contexto (no es una clase inyectable por tipo). */
export const PREDICT_CONTEXT = Symbol("predict-context");

@Controller()
export class PredictV1Controller {
  constructor(@Inject(PREDICT_CONTEXT) private readonly ctx: PredictContext) {}

  @Get("health")
  health(): { status: string } {
    return { status: "ok" };
  }

  /**
   * POST /spatial/predict
   * Predicción de acciones en lienzo visual interactivo con coordenadas y contexto anafórico.
   */
  @Post("spatial/predict")
  @HttpCode(200)
  async predictSpatial(@Body() body: SpatialPredictDto): Promise<VisualToolPayload> {
    if (!body || typeof body.query !== "string" || body.query.trim() === "") {
      throw new BadRequestException({ error: "El campo query (string) es requerido" });
    }
    const service = this.ctx.spatial ?? new SpatialPredictService(this.ctx.engine);
    const cursorStr = body.cursor ? `(${body.cursor.x.toFixed(2)}, ${body.cursor.y.toFixed(2)})` : "(0.50, 0.50)";
    console.log(`\n================== [SPATIAL HARNESS] ==================`);
    console.log(`📥 TEXTO TRANSCRIBIENDO/RECIBIDO : "${body.query}"`);
    console.log(`📍 CONTEXTO ESPACIAL             : Cursor=${cursorStr} | Seleccionado=${body.selectedId ?? "ninguno"}`);
    
    const result = await service.predict(body);
    
    console.log(`🛠️  HERRAMIENTA UTILIZADA        : [${result.tool}]`);
    console.log(`📦 PARÁMETROS                    :`, JSON.stringify(result.parameters));
    console.log(`🎯 CONFIANZA / LATENCIA          : ${(result.confidence * 100).toFixed(0)}% | ${result.executionTimeMs}ms`);
    console.log(`=======================================================\n`);
    return result;
  }

  @Post("predict/spatial")
  @HttpCode(200)
  async predictSpatialAlias(@Body() body: SpatialPredictDto): Promise<VisualToolPayload> {
    return this.predictSpatial(body);
  }

  /**
   * POST /predict
   * Body: { sessionId, tenant, agentId?, text, source: "human"|"agent", priorPlan?, keywords?, exclude? }
   * Respuesta: { tools, complexity, modelSize, rankedScores }
   *
   * `exclude` omite del resultado las herramientas ya ofrecidas en una pasada
   * previa (reintento del mini-agente con otras palabras clave).
   */
  @Post("predict")
  @HttpCode(200)
  async predict(@Body() body: Record<string, unknown>): Promise<unknown> {
    const b = body ?? {};
    const { sessionId, tenant, text, source, priorPlan, history, keywords, exclude } = b;
    if (typeof sessionId !== "string" || typeof tenant !== "string" || typeof text !== "string") {
      throw new BadRequestException({ error: "sessionId, tenant y text (string) requeridos" });
    }
    try {
      return await this.ctx.orchestrator.predict({
        sessionId,
        tenant,
        text,
        source: source === "agent" ? "agent" : "human",
        agentId: normalizeAgentId(b.agentId),
        priorPlan: typeof priorPlan === "string" ? priorPlan : undefined,
        keywords: Array.isArray(keywords) ? asNames(keywords) : undefined,
        exclude: Array.isArray(exclude) ? asNames(exclude) : undefined,
        history: Array.isArray(history)
          ? (history as { role?: unknown; content?: unknown }[])
              .filter((h) => h && typeof h.content === "string")
              .map((h) => ({ role: String(h.role ?? "user"), content: h.content as string }))
          : undefined,
      });
    } catch (err) {
      throw new InternalServerErrorException({ error: String((err as Error)?.message ?? err) });
    }
  }

  /**
   * POST /tools
   * Body: { tenant, agentId?, tools: ToolDefinition[] }
   * Respuesta: { indexed: number }
   */
  @Post("tools")
  @HttpCode(200)
  async registerTools(@Body() body: Record<string, unknown>): Promise<unknown> {
    const b = body ?? {};
    if (typeof b.tenant !== "string" || !Array.isArray(b.tools)) {
      throw new BadRequestException({ error: "tenant y tools[] requeridos" });
    }
    try {
      return await this.ctx.orchestrator.registerTools(
        b.tenant,
        b.tools as ToolDefinition[],
        normalizeAgentId(b.agentId),
      );
    } catch (err) {
      throw new InternalServerErrorException({ error: String((err as Error)?.message ?? err) });
    }
  }

  /**
   * POST /predict/feedback
   * Body: { tenant, agentId?, sessionId, text, used: string[], rejected?: string[] }
   * Respuesta: { ok: true, events }
   *
   * `used` debe contener SOLO herramientas cuya ejecución confirmó éxito real
   * (§8.1): reforzar las meramente predichas realimentaría los errores.
   */
  @Post("predict/feedback")
  @HttpCode(200)
  feedback(@Body() body: Record<string, unknown>): unknown {
    const b = body ?? {};
    const { sessionId, tenant, text } = b;
    if (typeof sessionId !== "string" || typeof tenant !== "string" || typeof text !== "string") {
      throw new BadRequestException({ error: "sessionId, tenant y text (string) requeridos" });
    }
    try {
      return this.ctx.orchestrator.feedback({
        sessionId,
        tenant,
        text,
        agentId: normalizeAgentId(b.agentId),
        used: asNames(b.used),
        rejected: asNames(b.rejected),
      });
    } catch (err) {
      throw new InternalServerErrorException({ error: String((err as Error)?.message ?? err) });
    }
  }

  /** GET /tools/count?tenant=&agentId= → {count} */
  @Get("tools/count")
  toolsCount(
    @Query("tenant") tenant?: string,
    @Query("agentId") agentId?: string,
  ): { count: number } {
    const t = typeof tenant === "string" ? tenant : "";
    return { count: t ? this.ctx.orchestrator.countTools(t, normalizeAgentId(agentId)) : 0 };
  }

  /**
   * POST /memory/predict
   * Body: { sessionId, tenant, agentId?, text, limit }
   * Respuesta: { memories, topicShift, topicScore, modelSize, rankedScores }
   */
  @Post("memory/predict")
  @HttpCode(200)
  async predictMemory(@Body() body: Record<string, unknown>): Promise<unknown> {
    const b = body ?? {};
    const { sessionId, tenant, text } = b;
    if (typeof sessionId !== "string" || typeof tenant !== "string" || typeof text !== "string") {
      throw new BadRequestException({ error: "sessionId, tenant y text (string) requeridos" });
    }
    try {
      return await this.ctx.orchestrator.predictMemory({
        sessionId,
        tenant,
        text,
        agentId: normalizeAgentId(b.agentId),
        limit: Number.isFinite(Number(b.limit)) ? Number(b.limit) : 8,
      });
    } catch (err) {
      throw new InternalServerErrorException({ error: String((err as Error)?.message ?? err) });
    }
  }

  /**
   * POST /memory/judge
   * Evalúa semánticamente si un hecho o texto representa ruido de negación de herramientas
   * no apto para persistir en memoria contextual de largo plazo.
   */
  @Post("memory/judge")
  @HttpCode(200)
  async judgeMemory(@Body() body: Record<string, unknown>): Promise<{ isNoise: boolean; noiseScore: number }> {
    const text = String(body?.text ?? "").trim();
    if (!text) return { isNoise: false, noiseScore: 0 };
    try {
      return await this.ctx.orchestrator.judgeMemory(text);
    } catch (err) {
      throw new InternalServerErrorException({ error: String((err as Error)?.message ?? err) });
    }
  }

  /**
   * POST /interest
   * Body: { sessionId, tenant, agentId?, text, anchors?: string[], limit? }
   * Respuesta: { interestScore, topic, topicScore, intentScore, matches, method }
   */
  @Post("interest")
  @HttpCode(200)
  async predictInterest(@Body() body: Record<string, unknown>): Promise<unknown> {
    const b = body ?? {};
    const { sessionId, tenant, text } = b;
    if (typeof sessionId !== "string" || typeof tenant !== "string" || typeof text !== "string") {
      throw new BadRequestException({ error: "sessionId, tenant y text (string) requeridos" });
    }
    try {
      return await this.ctx.orchestrator.predictInterest({
        sessionId,
        tenant,
        text,
        agentId: normalizeAgentId(b.agentId),
        anchors: Array.isArray(b.anchors)
          ? (b.anchors as unknown[]).filter((a): a is string => typeof a === "string")
          : undefined,
        limit: Number.isFinite(Number(b.limit)) ? Number(b.limit) : undefined,
      });
    } catch (err) {
      throw new InternalServerErrorException({ error: String((err as Error)?.message ?? err) });
    }
  }

  /**
   * GET /debug?tenant=&agentId= → engine, stats, trazas de las últimas
   * predicciones y el resumen del perfil léxico aprendido del canal (F3).
   */
  @Get("debug")
  async debug(
    @Query("tenant") tenant?: string,
    @Query("agentId") agentId?: string,
  ): Promise<{
    engine: { size: string; modelPath: string };
    stats: unknown;
    traces: unknown;
    lexical?: unknown;
  }> {
    const engineInfo = await this.ctx.engine.getInfo(this.ctx.engine.defaultSize);
    const snapshot = this.ctx.debugger.snapshot();
    const t = typeof tenant === "string" ? tenant.trim() : "";
    return {
      engine: { size: engineInfo.model, modelPath: engineInfo.modelPath },
      stats: snapshot.stats,
      traces: snapshot.traces,
      lexical: t === "" ? undefined : this.ctx.lexical.snapshot(resolveScopeKey(t, normalizeAgentId(agentId))),
    };
  }
}

/** Normaliza una lista de nombres de herramienta recibida por HTTP. */
function asNames(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((v): v is string => typeof v === "string");
}
